/**
 * Loggin with user's signup email on FTC site.
 */
const Router = require('koa-router');
const debug = require('../util/debug')('user:login');
const Joi = require('joi');
const request = require('superagent');
const schema = require('./schema');
const render = require('../util/render');
const endpoints = require('../util/endpoints');

const router = new Router();

router.get('/', async function (ctx) {
  ctx.body = await render('login.html', ctx.state);
});

router.post('/', async function (ctx, next) {

  /**
   * @type {{login: string, password: string}} credentials
   */
  const credentials = ctx.request.body.credentials;

  try {

    const resp = await request.post(`${endpoints.staff}/auth`)
      .send(credentials)
      .send({
        ip: ctx.ip
      });

    /**
     * @type {ICMSAuth}
     */
    const account = resp.body;
    debug.info('Authentication result: %o', account);

    /**
     * @type {ISession}
     */
    const userSession = {
      id: account.id,
      name: account.login,
      display: account.displayName,
      groups: account.groups,
      dpmt: account.department
    }

    // Keep login state
    ctx.session.user = userSession;

    ctx.redirect('/');

  } catch (e) {
    if (!e.response) {
      throw e;
    }

    if (404 == e.status) {
      // Unauthorized means password incorrect
      debug.info('Password incorrect');
      ctx.state.errors = {
        credentials: "用户名或密码无效"
      };
      return await next();
    }

    return ctx.body = e.response.body;
  }
}, async function (ctx) {
  ctx.body = await render('login.html', ctx.state);
});

module.exports = router.routes();
