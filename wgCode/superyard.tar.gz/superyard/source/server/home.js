const debug = require('../util/debug')('user:home');
const render = require('../util/render');

async function showHome(ctx, next) {
  ctx.body = await render('home.html', ctx.state);
};

module.exports = showHome;