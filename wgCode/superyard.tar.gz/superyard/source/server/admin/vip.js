const Router = require('koa-router');
const request = require('superagent');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');

const router = new Router();

router.get('/applications', async (ctx, next) => {
  ctx.body = await render('admin/vip.html', ctx.state);
});

router.get('/:id/grant', async (ctx, next) => {
  const staffId = ctx.params.id;

  try {
    await request.put(`${endpoints.adminVip}/${staffId}/grant`);

    ctx.redirect('/admin/vip/applications');
  } catch (e) {

  }
});

router.get('/:id/reject', async (ctx, next) => {
  const staffId = ctx.params.id;

  try {
    await request.put(`${endpoints.adminVip}/${staffId}/reject`);

    ctx.redirect('/admin/vip/applications');
  } catch (e) {

  }
});

router.get('/:id/revoke', async (ctx, next) => {
  const staffId = ctx.params.id;

  try {
    await request.put(`${endpoints.adminVip}/${staffId}/revoke`);

    ctx.redirect('/admin/vip/applications');
  } catch (e) {

  }
});

module.exports = router.routes();