const Router = require('koa-router');
const request = require('superagent');

const newStaff = require('./new-staff');
const staffProfile = require('./staff-profile');
// const vip = require('./vip');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');

const router = new Router();

router.get('/', async (ctx, next) => {
  ctx.body = await render('admin/home.html', ctx.state);
});

router.use('/new-staff', newStaff);

router.get('/staff', async (ctx, next) => {
  try {
    const resp = await request.get(`${endpoints.adminStaff}`);

    ctx.state.profiles = resp.body;

    ctx.body = await render('admin/roster.html', ctx.state);
  } catch (e) {
    throw e;
  }
});

router.use('/staff', staffProfile);
// router.use('/vip', vip);

module.exports = router.routes();