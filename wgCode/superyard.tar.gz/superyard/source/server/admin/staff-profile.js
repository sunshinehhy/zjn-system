const Router = require('koa-router');
const request = require('superagent');
const debug = require('../../util/debug')('patio:admin.staff-profile');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');
const groups = require('../../lib/groups');
const departments = require('../../lib/departments');

const router = new Router();

const config = {
  path: '/admin/staff'
}
// Show a staff's profile
router.get('/:id', async (ctx, next) => {
  const staffId = ctx.params.id;
  const password = ctx.session.password;

  try {
    const resp = await request.get(`${endpoints.adminStaff}/${staffId}`);

    /**
     * @type {ICMSUserInput}
     */
    const profile = resp.body;

    ctx.state.profile = profile;
    // Build user groups list
    ctx.state.groupList = groups.list(profile.groupMembers);
    // Build departments list
    ctx.state.departments = departments;

    ctx.body = await render('admin/staff-profile.html', ctx.state);
  } catch (e) {
    throw e;
  }
});

// Update a staff's profile
router.post('/:id', async (ctx, next) => {
  /**
   * @type {{_csrf: string, profile: ICMSUserInput, groups: number[]}}
   */
  const input = ctx.request.body;

  const profile = input.profile;
  // Sum groups the user belongs to
  profile.groupMembers = groups.sum(input.groups);

  /**
   * @type {number}
   */
  const staffId = ctx.params.id;

  debug.info('Updating staff %d', staffId);
  debug.info('Updated profile: %o', profile);

  try {
    await request.post(`${endpoints.adminStaff}/${staffId}`)
      .send(profile);

    // Show the updated profile
    ctx.redirect(ctx.path);
  } catch(e) {
    throw e;
  }
});

// Delete a user and optionally remove vip status
router.post('/:id/delete', async (ctx, next) => {
  /**
   * @type {{_csrf: string, rmVip: boolean}}
   */
  const input = ctx.request.body;

  const staffId = ctx.params.id;

  try {
    await request.delete(`${endpoints.adminStaff}/${staffId}`);

    ctx.redirect(config.path);
  } catch (e) {
    throw e;
  }
});

module.exports = router.routes();