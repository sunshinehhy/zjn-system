const Router = require('koa-router');
const request = require('superagent');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');
const groups = require('../../lib/groups');
const departments = require('../../lib/departments');

const router = new Router();
const config = {
  path: '/admin/new-staff',
  staffPath: '/admin/staff'
}

router.use(async (ctx, next) => {
  ctx.state.config = config;
  await next();
});

// Show create new staff page
router.get('/', async (ctx, next) => {
  ctx.body = await render('admin/new-staff.html', ctx.state);
});

// Check user name to determine next step: does this user exist but deactivated or not exist?
router.post('/next', async (ctx, next) => {
  /**
   * @type {{login: string}}
   */
  const staff = ctx.request.body.staff;
  
  try {
    // Check if user exists
    const resp = await request.get(`${endpoints.search}/staff`)
      .query({
        k: 'login',
        v: staff.login
      });

    // User exists. Get user profile
    // Possible senario: User exists but not active; User exists and active; User does not exist.
    const profile = resp.body;

    ctx.state.profile = profile;
    
    ctx.body = await render('admin/activate-staff.html', ctx.state);

  } catch (e) {
    if (e.status !== 404) {
      throw e;
    }

    // If response status is 404, it means the user is not found.
    ctx.state.staff = staff;
    // Compose a human readable group list
    ctx.state.groupList = groups.list();
    // Department list
    ctx.state.departments = departments;

    ctx.body = await render('admin/create-staff.html', ctx.state);
  }
});

// Activate a user if it's deactivated. This will not generate a new password. If the user forgot password, use forgot password function.
router.post('/activate', async (ctx, next) => {
  /**
   * @type {{id: number}}
   */
  const staff = ctx.request.body.staff;

  try {
    await request.put(`${endpoints.adminStaff}/${staff.id}`);

    ctx.redirect(`${config.staffPath}/${staff.id}`);

  } catch (e) {
    throw e;
  }
});

// Create a user
router.post('/create', async (ctx, next) => {
  // Receive new user id from API, then redirect to new user page /admin/staff/profile/:id
  /**
   * @type {{_csrf: string, staff: ICMSUserInput, groups: number[]}}
   */
  const input = ctx.request.body;
  const staff = input.staff;

  staff.groupMembers = groups.sum(input.groups);

  try {
    const resp = await request.post(`${endpoints.adminStaff}`)
      .send(staff);

    /**
     * @type {{id: number, password: string}}
     */
    const account = resp.body;

    // Send welcome letter
    request.post(endpoints.emailWelcome)
      .send({
        name: staff.displayName,
        address: staff.email,
        login: staff.login,
        password: account.password,
        homeUrl: `${ctx.protocol}://${ctx.host}`
      })
      .catch(err => {
        debug.error(err);
      });

    ctx.redirect(`${config.staffPath}/${account.id}`);

  } catch (e) {
    throw e;
  }
});

module.exports = router.routes();