const Router = require('koa-router');
const request = require('superagent');
const oauthGrant = require('../../lib/oauth-grant');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');
const debug = require('../../util/debug')('patio:ftc-app');
const {groupMembers} = require('../../lib/groups');

const router = new Router();
const config = {
  path: '/registry/ftc',
  heading: 'FTC OAuth',
  appType: 'ftc',
  isOAuth: true
}

router.use(async (ctx, next) => {
  ctx.state.config = config;
  await next()
});

// Show all FTC apps
router.get('/', async (ctx) => {
  try {

    const resp = await request.get(`${endpoints.ftcApp}`);
    
    ctx.state.config = config;
    ctx.state.apps = resp.body;

    ctx.body = await render('registry/app-roster.html', ctx.state);
  } catch(e) {
    throw e;
  }
});

// Show UI to create a new FTC app
router.get('/new', async (ctx) => {
  ctx.state.config = config;
  ctx.state.oauthChoices = oauthGrant.list();

  ctx.body = await render('registry/new-app.html', ctx.state);
});

// Create a FTC app
router.post('/new', async (ctx) => {
  /**
   * @type {{_csrf: string, app: IFTCAppInput}}
   */
  const input = ctx.request.body;

  const app = input.app;
  app.grantType = Number.parseInt(app.grantType);

  debug.info('Create a new ftc app: %O', app);

  /**
   * @type {number}
   */
  const ownerId = ctx.session.user.id;

  try {
    const resp = await request.post(`${endpoints.ftcApp}`)
      .send(app)
      .send({ownerId});
    
    const appId = resp.body.id;

    ctx.redirect(`${config.path}/${appId}`);
  } catch (e) {
    throw e;
  }
});

// Show details of a FTC app
// Do not allow editing if: not owned by current user, deprecated.
// Do not show Reset Client Secret button if:  it does not have client secret; not owned by current user.
// Do not show tranfer button if: it is not owned by current user; deprecated
router.get('/:appId', async (ctx) => {
  /**
   * @type {number}
   */
  const appId = ctx.params.appId;
  /**
   * @type {number}
   */
  const ownerId = ctx.session.user.id;

  try {
    const resp = await request.get(`${endpoints.ftcApp}/${appId}`);
    /**
     * @type {IFTCApp}
     */
    const app = resp.body;
    // Determine if the content is editable
    app.isOwner = ownerId === app.ownerId;
    app.grantType = oauthGrant.find(app.grantType)

    debug.info('App: %O', app);

    ctx.state.config = config;
    ctx.state.app = app;

    ctx.body = await render('registry/edit-app.html', ctx.state);

  } catch (e) {
    throw e;
  }
});

// Update a FTC app
router.post('/:appId', async (ctx) => {
  /**
   * @type {{_csrf: string, app: Object}}
   */
  const input = ctx.request.body;
  /**
   * @type {IFTCAppInput} - no `grantType` field
   */
  const app = input.app;
  /**
   * @type {number}
   */
  const appId = ctx.params.appId;
  /**
   * @type {number}
   */
  const ownerId = ctx.session.user.id;

  try {
    const resp = await request.post(`${endpoints.ftcApp}/${appId}`)
      .send(app)
      .send({ownerId});
    
    ctx.redirect(`${config.path}/${appId}`);

  } catch (e) {
    throw e;
  }
});

// Reset the OAuth client secret of a FTC app
router.post('/:appId/reset-secret', async (ctx) => {
  /**
   * @type {{_csrf: string}}
   */
  const input = ctx.request.body;
  /**
   * @type {number}
   */
  const appId = Number.parseInt(ctx.params.appId, 10);
  /**
   * @type {number}
   * @todo Perform validation to make sure this is a number
   */
  const ownerId = ctx.session.user.id;

  try {
    await request.post(`${endpoints.ftcApp}/${appId}/reset-secret`)
      .send({ownerId});

    ctx.redirect(`${config.path}/${appId}`);

  } catch (e) {
    throw e;
  }
});

// Show transfer app page
router.get('/:appId/transfer', async (ctx) => {
  /**
   * @type {number} - this app's owner id
   */
  const ownerId = ctx.session.user.id;

  try {
    // Get developers only.
    const resp = await request.get(`${endpoints.staffActive}?group=${groupMembers.developer}`);

    /**
     * @type {ICMSUser[]}
     */
    const users = resp.body;

    // Transfer targets should not include yourself.
    ctx.state.transferTargets = users.filter(user => {
      return user.id !== ownerId
    });
    ctx.state.appId = ctx.params.appId;
    
    ctx.body = await render('registry/transfer-app.html', ctx.state);

  } catch (e) {
    throw e;
  }
  
});

// Transfer this app to others
router.post('/:appId/transfer', async (ctx) => {
  /**
   * @type {{_csrf: string, newOwnerId: number}}
   */
  const input = ctx.request.body;
  const newOwnerId = Number.parseInt(input.newOwnerId);

  // Validate input data
  if (!Number.isInteger(newOwnerId) || newOwnerId <= 0) {
    throw new Error('New owner id must be greater than 0');
  }

  /**
   * @type {number}
   */
  const appId = Number.parseInt(ctx.params.appId, 10);
  /**
   * @type {number}
   */
  const currentOwnerId = ctx.session.user.id;

  try {
    await request.post(`${endpoints.ftcApp}/${appId}/transfer`)
      .send({
        currentOwnerId,
        newOwnerId
      });

    ctx.redirect(`${config.path}/${appId}`);

  } catch (e) {
    throw e;
  }
});

// Delete this app
router.post('/:appId/delete', async (ctx) => {
  /**
   * @type {{_csrf: string}}
   */
  const input = ctx.request.body;
  /**
   * @type {number}
   */
  const appId = Number.parseInt(ctx.params.appId, 10);
  /**
   * @type {number}
   */
  const ownerId = ctx.session.user.id;

  try {
    await request.delete(`${endpoints.ftcApp}/${appId}`)
      .send({ownerId});

    // Go back to app list page.
    ctx.redirect(`${config.path}`);
  } catch (e) {
    throw e;
  }
});

// Show tokens of this app
router.get('/:appId/tokens', async (ctx) => {
  
});

// Revoke all tokens of this app
router.post('/:appId/tokens/revoke', async (ctx) => {
  
});

module.exports = router.routes();