const Router = require('koa-router');
const request = require('superagent');

const render = require('../../util/render');
const endpoints = require('../../util/endpoints');
const groups = require('../../lib/groups');
const unixPerms = require('../../lib/unix-perms');

const router = new Router();

const config = {
  path: '/registry/cms',
  heading: 'CMS',
  appType: 'cms'
};

router.use(async (ctx, next) => {
  ctx.state.config = config;
  await next();
});

// List all cms apps
router.get('/', async (ctx) => {
  try {
    const resp = await request.get(`${endpoints.cmsApp}`);

    ctx.state.apps = resp.body;

    ctx.body = await render('registry/app-roster.html', ctx.state);
  } catch (e) {
    throw e;
  }

});

// Show UI to create an new CMS app
router.get('/new', async (ctx) => {
  ctx.state.groupList = groups.list();
  ctx.state.permissions = unixPerms.list();

  ctx.body = await render('registry/new-app.html', ctx.state);
});

router.post('/new', async (ctx) => {
  /**
   * @type {{_csrf: string, app: ICMSAppInput, permissions: IPermissions}}
   */
  const input = ctx.request.body;
  const app = input.app;
  app.unixPerms = unixPerms.sum(input.permissions);
  app.ownerId = ctx.session.user.id;

  try {
    const resp = await request.post(`${endpoints.cmsApp}`)
      .send(app);

    const appId = resp.body.id;

    ctx.redirect(`${config.path}/${appId}`);

  } catch (e) {
    throw e;
  }
});

// Show details of a CMS app
router.get('/:appId', async (ctx) => {
  /**
   * @type {number}
   */
  const appId = ctx.params.appId;
  /**
   * @type {number}
   */
  const ownerId = ctx.session.user.id;

  try {
    const resp = await request.get(`${endpoints.cmsApp}/${appId}`);

    /**
     * @type {ICMSApp}
     */
    const app = resp.body;
    app.isOwner = ownerId === app.ownerId;

    ctx.state.app = app;
    // Show current allowed groups
    ctx.state.groupList = groups.list(app.groupId);
    // Show current granted permissions
    ctx.state.permissions = unixPerms.list(app.unixPerms);

    ctx.body = await render('registry/edit-app.html', ctx.state);
  } catch (e) {
    throw e;
  }
});

router.post('/:appId', async (ctx) => {
  /**
   * @type {{_csrf: string, app: ICMSAppInput, permissions: IPermissions}}
   */
  const input = ctx.request.body;

  const app = input.app;
  app.unixPerms = unixPerms.sum(input.permissions);
  app.ownerId = ctx.session.user.id;

  const appId = ctx.params.appId;

  try {
    const resp = await request.post(`${endpoints.cmsApp}/${appId}`)
      .send(app);

    ctx.redirect(`${config.path}/${appId}`);

  } catch (e) {
    throw e;
  }
});

// Show transfer app page
router.get('/:appId/transfer', async (ctx) => {
  /**
   * @type {number} - this app's owner id
   */
  const ownerId = ctx.session.user.id;

  try {
    // Get developers only.
    const resp = await request.get(`${endpoints.staffActive}?group=${groups.groupMembers.developer}`);

    /**
     * @type {ICMSUser[]}
     */
    const users = resp.body;

    // Transfer targets should not include yourself.
    ctx.state.transferTargets = users.filter(user => {
      return user.id !== ownerId
    });
    ctx.state.appId = ctx.params.appId;

    ctx.body = await render('registry/transfer-app.html', ctx.state);

  } catch (e) {
    throw e;
  }
  
});

router.post('/:appId/transfer', async (ctx) => {
  /**
   * @type {{_csrf: string, newOwnerId: number}}
   */
  const input = ctx.request.body;
  const newOwnerId = Number.parseInt(input.newOwnerId);

  // Validate input data
  if (!Number.isInteger(newOwnerId) || newOwnerId <= 0) {
    throw new Error('New owner id must be greater than 0');
  }

  /**
   * @type {number}
   */
  const appId = Number.parseInt(ctx.params.appId, 10);
  /**
   * @type {number}
   */
  const currentOwnerId = ctx.session.user.id;

  try {
    await request.post(`${endpoints.cmsApp}/${appId}/transfer`)
      .send({
        currentOwnerId,
        newOwnerId
      });

    ctx.redirect(`${config.path}/${appId}`);

  } catch (e) {
    throw e;
  }
});

router.post('/:appId/delete', async (ctx) => {
  /**
   * @type {{_csrf: string}}
   */
  const input = ctx.request.body;
  /**
   * @type {number}
   */
  const appId = Number.parseInt(ctx.params.appId, 10);
  /**
   * @type {number}
   */
  const ownerId = ctx.session.user.id;

  try {
    await request.delete(`${endpoints.cmsApp}/${appId}`)
      .send({ownerId});

    // Go back to app list page.
    ctx.redirect(`${config.path}`);
  } catch (e) {
    throw e;
  }
});

module.exports = router.routes();