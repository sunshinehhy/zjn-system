const Router = require('koa-router');
const request = require('superagent');
const _ = require('lodash');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');
const debug = require('../../util/debug')('patio:personal-token');
const regexify = require('../../lib/regexify');

const router = new Router();

const config = {
  path: '/registry/tokens'
};

router.use(async (ctx, next) => {
  ctx.state.config = config;
  await next();
});

// Show all tokens of current user
router.get('/', async (ctx, next) => {
  const ownerId = ctx.session.user.id;
  const userName = ctx.session.user.name;

  /**
   * @type {{id: number, token: string}}
   */
  const newAccess = ctx.session.newAccess;

  try {
    // Token list
    const resp = await request.get(`${endpoints.personalToken}/${ownerId}`);

    /**
     * @type {IPersonalAccess[]}
     */
    const accessRoster = resp.body;

    if (newAccess) {
      const index = _.findIndex(accessRoster, function(item) {
        return item.id == newAccess.id
      });

      if (index !== -1) {
        accessRoster[index].accessToken = newAccess.token;
      }
    }

    ctx.state.tokens = accessRoster;
    ctx.state.newAccess = newAccess;
    // Regular expression pattern to verify username when user tries to delete all tokens
    ctx.state.namePattern = regexify.name(userName);

    ctx.body = await render('token/token-roster.html', ctx.state);

    delete ctx.session.newAccess;

  } catch (e) {
    throw e;
  }
});

// Show create new token page
router.get('/new', async (ctx, next) => {

  const staffId = ctx.session.user.id;

  try {
    // Get myft accounts
    const resp = await request.get(`${endpoints.staffProfile}/${staffId}/myft`);

    ctx.state.myft = resp.body;

    debug.info('%O', ctx.state);

    ctx.body = await render('token/new-token.html', ctx.state);
  } catch (e) {
    throw e;
  }
});

// Create a new personal access token
router.post('/new', async (ctx, next) => {
  /**
   * @type {{_csrf: string, token: Object}}
   */
  const input = ctx.request.body;
  /**
   * @type {{description: string, myftId: string, ownerId: number}}
   */
  const token = input.token;
  token.ownerId = ctx.session.user.id;

  try {
    // Returns the new access token {{id: number, token: string}}
    const resp = await request.post(`${endpoints.personalToken}`)
      .send(token);

    ctx.session.newAccess = resp.body;

    ctx.redirect(config.path)
  } catch (e) {
    throw e;
  }
});

// Create all personal access tokens a user owns
router.post('/revoke-all', async (ctx, next) => {
  const ownerId = ctx.session.user.id;
  try {
    await request.delete(`${endpoints.personalToken}/${ownerId}`);

    ctx.redirect(config.path);
  } catch (e) {
    throw e;
  }
});

// Show details of one access token
router.get('/:tokenId', async (ctx, next) => {
  const ownerId = ctx.session.user.id;
  const tokenId = ctx.params.tokenId;

  try {
    const resp = await request.get(`${endpoints.personalToken}/${ownerId}/${tokenId}`);

    ctx.state.token = resp.body;

    ctx.body = await render('token/edit-token.html', ctx.state);

  } catch (e) {
    throw e;
  }
});

// Update one personal access token
router.post('/:tokenId', async (ctx, next) => {
  /**
   * @type {{_csrf: string, token: Object}}
   */
  const input = ctx.request.body;

  /**
   * @type {{description: string}}
   */
  const token = input.token;

  const ownerId = ctx.session.user.id;
  const tokenId = ctx.params.tokenId;

  try {
    await request.post(`${endpoints.personalToken}/${ownerId}/${tokenId}`)
      .send(token);

    ctx.redirect(`${config.path}/${tokenId}`);
  } catch (e) {
    throw e;
  }
});

// Regnerate a personal access token
router.post('/:tokenId/regenerate', async (ctx, next) => {
  const ownerId = ctx.session.user.id;
  const tokenId = ctx.params.tokenId;

  try {
    const resp = await request.post(`${endpoints.personalToken}/${ownerId}/${tokenId}/regenerate`);

    const newAccess = resp.body;

    ctx.session.newAccess = newAccess;

    ctx.redirect(config.path);

  } catch (e) {
    throw e;
  }
});

// Revoke a personal access token
router.post('/:tokenId/revoke', async (ctx, next) => {
  const ownerId = ctx.session.user.id;
  const tokenId = ctx.params.tokenId;
  try {
    await request.delete(`${endpoints.personalToken}/${ownerId}/${tokenId}`);

    ctx.redirect(config.path);
    
  } catch (e) {
    throw e;
  }
});

module.exports = router.routes();