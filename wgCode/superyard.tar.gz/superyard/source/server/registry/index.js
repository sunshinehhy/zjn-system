const Router = require('koa-router');
const request = require('superagent');

const render = require('../../util/render');
const endpoints = require('../../util/endpoints');

const ftcApp = require('./ftc-app');
const cmsApp = require('./cms-app');
const personalToken = require('./personal-token');

const router = new Router();

/**
 * @description /registry/
 */
router.get('/', async (ctx) => {
  ctx.body = await render('registry/guide.html', ctx.state);
});

/**
 * @description /registry/ftc
 */
router.use('/ftc', ftcApp);

/**
 * @description /registry/backyard
 */
router.use('/cms', cmsApp);

/**
 * @description /registry/tokens
 */
router.use('/tokens', personalToken);

module.exports = router.routes();