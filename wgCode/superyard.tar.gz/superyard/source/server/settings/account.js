const Router = require('koa-router');
const request = require('superagent');
const assert = require('assert');

const debug = require('../../util/debug')('patio:settings.profile');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');
const ensure = require('../../util/ensure');

const router = new Router();

const config = {
  path: '/settings/account'
};

router.use(async (ctx, next) => {
  ctx.state.config = config;
  await next();
});

// Show account page
router.get('/', async (ctx, next) => {
  const done = ctx.session.done;
  ctx.state.done = done
  ctx.body = await render('settings/account.html', ctx.state);
  delete ctx.session.done;
});

// Change password
router.post('/password', async (ctx, next) => {
  
  /**
   * @type {{_csrf: string, password: Object}}
   */
  const input = ctx.request.body;

  /**
   * @type {{old: string, new: string, confirm: string}}
   */
  const password = input.password;

  // New password must be equal to confirmed password.
  ensure.equals(password.new, password.confirm, 'New password does not match the confirmed one');

  // New password must not be equal to old password
  ensure.notEquals(password.old, password.new, 'New password should be different from the old one');

  // staffId must be defined
  const staffId = ctx.session.user.id;

  ensure.defined(staffId, 'staffId must be defined');

  try {
    const resp = await request.post(`${endpoints.staffProfile}/${staffId}/password`)
      .send({
        oldPassword: password.old,
        newPassword: password.new
      });
    
    ctx.session.done = true;
    ctx.redirect(config.path);

  } catch (e) {
    if (e.status === 404) {
      throw new Error('You current password is not correct');
    }
    throw e;
  }
});

module.exports = router.routes();