const Router = require('koa-router');
const request = require('superagent');
const debug = require('../../util/debug')('patio:settings.profile');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');
const groups = require('../../lib/groups');

const router = new Router();

const config = {
  path: '/settings/profile'
};

router.use(async (ctx, next) => {
  ctx.state.config = config;
  await next();
});

// Show a user's profile
router.get('/', async (ctx, next) => {
  const staffId = ctx.session.user.id;
  debug.info("User id: %s", staffId);

  try {
    const resp = await request.get(`${endpoints.staffProfile}/${staffId}`);

    /**
     * @type {ICMSUser}
     */
    const profile = resp.body;
    profile.groups = groups.dissect(profile.groupMembers);

    debug.info(profile);

    ctx.state.profile = profile;
    ctx.body = await render('settings/profile.html', ctx.state);

  } catch (e) {
    if (!e.response) {
      throw e;
    }

    ctx.body = e.response.body;
  }
});

// Update a user's profile
// Currently only displayName is allowed to be updated by user.
router.post('/', async (ctx, next) => {
  /**
   * @type {{_csrf: string, profile: Object}}
   */
  const input = ctx.request.body;

  /**
   * @type {{displayName: string}}
   */
  const profile = input.profile

  const staffId = ctx.session.user.id;

  try {
    const resp = await request.post(`${endpoints.staffProfile}/${staffId}`)
      .send(profile);

    return ctx.redirect(config.path);
  } catch (e) {
    throw e;
  }
});

module.exports = router.routes();