const Router = require('koa-router');
const profile = require('./profile');
const account = require('./account');
const myft = require('./myft');
// const vip = require('./vip');

const router = new Router();

router.use('/profile', profile);

router.use('/account', account);

router.use('/myft', myft);

// router.use('/vip', vip)

module.exports = router.routes();