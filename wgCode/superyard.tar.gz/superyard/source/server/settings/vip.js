const Router = require('koa-router');
const request = require('superagent');

const debug = require('../../util/debug')('patio:settings.profile');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');

const router = new Router();

router.post('/', async (ctx, enxt) => {
  const staffId = ctx.session.user.sub;

  try {
    const resp = await request.put(`${endpoints.staffProfile}/${staffId}/vip`);

    // Show latest profile
    ctx.redirect('/settings/profile');
  } catch (e) {
    // Network error
    if (!e.response) {
      throw e;
    }

    return ctx.body = e.response.body;
  }
});

module.exports = router.routes();