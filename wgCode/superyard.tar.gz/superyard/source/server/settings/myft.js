const Router = require('koa-router');
const request = require('superagent');

const debug = require('../../util/debug')('patio:settings.profile');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');

const router = new Router();

const config = {
  path: '/settings/myft'
};

router.use(async (ctx, next) => {
  ctx.state.config = config;
  await next();
});

// List all user's myft accounts.
router.get('/', async (ctx, next) => {
  const staffId = ctx.session.user.id;

  try {
    const resp = await request.get(`${endpoints.staffProfile}/${staffId}/myft`);

    /**
     * @type {IMyft[]}
     */
    const myftAccounts = resp.body;
    ctx.state.myft = myftAccounts;

    ctx.body = await render('settings/myft.html', ctx.state);

  } catch (e) {
    throw e;
  }
});

// Add a myft account
router.post('/', async (ctx, next) => {
  const staffId = ctx.session.user.id;

  const credentials = ctx.request.body.credentials;

  try {
    debug.info('Verify myft account');

    const resp = await request.post(`${endpoints.staffProfile}/${staffId}/myft`)
      .send(credentials);

    ctx.redirect(config.path);

  } catch (e) {
    throw e;
  }
});

module.exports = router.routes();