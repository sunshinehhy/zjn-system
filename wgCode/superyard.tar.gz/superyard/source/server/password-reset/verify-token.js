const {dirname} = require('path')
const request = require('superagent');
const debug = require('../../util/debug')('user:verify-rest-token');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');

module.exports = async function (ctx, next) {
  const token = ctx.params.token;

  try {
    const resp = await request.get(`${endpoints.staff}/password-reset/${token}`);

    /**
     * @type {string}
     */
    const email = ctx.request.body.email;
    ctx.state.email = email;
    
    ctx.body = await render('password-reset/new-password.html', ctx.state);

  } catch (e) {
    if (!e.response) {
      throw e;
    }

    if (404 === e.status) {
      ctx.session.invalidLink = true;

      // Redirect to /password-reset
      const redirectTo = dirname(ctx.path);

      return ctx.redirect(redirectTo);
    }
  }
}