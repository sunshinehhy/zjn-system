const request = require('superagent');
const {dirname} = require('path');
const schema = require('../schema');
const debug = require('../../util/debug')('user:reset-password');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');
const ensure = require('../../util/ensure');

exports.do = async (ctx, next) => {
  const token = ctx.params.token;
  /**
   * @type {{password: string, confirmPassword: string, email: string}}
   */
  const body = ctx.request.body;

  const [password, ] = ensure.equals(password, confirmPassword, 'Passwords inconsistant')

  try {
    const resp = await request.post(`${endpoints.staff}/password-reset`)
      .send({
        email: body.email,
        token,
        password: password
      });

    debug.info('API success reponse: %O', resp.noContent);

    ctx.session.pwReset = true;
    return ctx.redirect(dirname(ctx.path));

  } catch (e) {
    if (!e.response || 404 !== e.status) {
      throw e;
    }

    ctx.session.invalidLink = true;

    // Redirect to /password-reset
    const redirectTo = dirname(ctx.path);

    debug.info('Token %s not found. Redirect to %s', token, redirectTo);

    return ctx.redirect(redirectTo);

  }
};

exports.showErrors = async function(ctx) {
  ctx.body = await render('password/new-password.html', ctx.state);
}