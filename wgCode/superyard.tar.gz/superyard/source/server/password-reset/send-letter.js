const request = require('superagent');
const debug = require('../../util/debug')('user:send-letter');
const render = require('../../util/render');
const endpoints = require('../../util/endpoints');
const random = require('../../util/random');
const ensure = require('../../util/ensure');
/**
 * @description Collect user entered email and ask API to send letter.
 */
module.exports = async function (ctx, next) {
  /**
   * @type {{email: string}}
   */
  const input = ctx.request.body;
  let email = '';
  try {
    email = ensure.ftcEmail(input.email);
  } catch (e) {
    ctx.state.email = input.email;

    ctx.state.errors = {
      invalidEmail: true
    };

    return await next();
  }

  /**
   * @type {{email: string, token: string}}
   */
  let letterComp;
  try {
    const resp = await request.post(`${endpoints.staff}/password-reset/tokens`)
      .send({email});

    letterComp = resp.body;
  } catch (e) {
    debug.error(e);
    if (!e.response || e.status !== 404) {
      throw e;
    }
    
    ctx.state.email = email;
    ctx.state.errors = {
      emailNotFound: true
    }
    
    return await next();
  }

  // ask email-service to send email
  try {
    const resp = await request.post(endpoints.emailPasswordReset)
      .send({
        address: email,
        resetLink: `${ctx.href}/${letterComp.token}`,
        homeUrl: ctx.href
      });

    ctx.session.letterSent = true;
    ctx.redirect(ctx.path);
  } catch (e) {
    throw e;
  }
}