const Router = require('koa-router');
const render = require('../../util/render');

const enterEmail = require('./enter-email');
const sendLetter = require('./send-letter');
const verifyToken = require('./verify-token');
const reset = require('./reset');

const router = new Router();

// Ask user to enter email
router.get('/', enterEmail);

// Check email and send reset letter if exists
router.post('/', sendLetter, enterEmail);

// Verify reset link
router.get('/:token', verifyToken);

// Enter new password
router.post('/:token', reset.do, reset.showErrors);

module.exports = router.routes();