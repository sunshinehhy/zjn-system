/**
 * @description Navigation items of the entire site visible on left side bar or top nav bar.
 */
exports.main = [
  {
    name: "Admin",
    path: "/admin"
  },
  {
    name: "APN",
    path: "http://apn.ftchinese.com/login"
  },
  {
    name: "OAuth 2.0",
    path: "/oauth"
  },
  {
    name: "Translation",
    path: "/tranlsation"
  },
  {
    name: "Editorial",
    path: "/editorial"
  }
];

exports.admin = [
  {
    name: "Admin Home",
    path: ""
  },
  {
    name: "Staff Admin",
    path: "/staff"
  },
  {
    name: "VIP Application",
    path: "/vip"
  }
];

exports.settings = [
  {
    name: "My Profile",
    path: "/settings/profile"
  },
  {
    name: "Security",
    path: "/settings/security"
  },
  {
    name: "MyFT Account",
    path: "/settings/myft"
  }
];