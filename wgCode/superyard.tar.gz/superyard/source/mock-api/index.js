const assert = require('assert');
const Koa = require('koa');
const Router = require('koa-router');
const logger = require('koa-logger');
const bodyParser = require('koa-bodyparser');
const bootApp = require('../util/boot-app');
const _ = require('lodash');

const app = new Koa();
const router = new Router();

app.use(async function(ctx, next) {
  try {
    await next();
  } catch (e) {
    log.error(e);
    
    ctx.status = e.status || 500;
    ctx.body = {
      code: e.code,
      message: e.message,
      stack: e.stack
    };
  }
});

app.use(logger());
app.use(bodyParser());

const users = [
  {
    userId: 1,
    userName: 'foo.baz',
    displayName: 'Foo Baz',
    groups: 8
  }
];

const resetLinks = [
  {
    token: 'c671a86e5492bc9e7a80ca11308c994bc7fb8c7101fae1e7115a7a335f96aaee',
    email: 'valid@ftchinese.com'
  }
];

router.post('/staff/auth', async (ctx, next) => {
  const input = ctx.request.body;
  const expected = {
    usreName: 'foo.baz',
    password: '12345678',
    ip: '127.0.0.1'
  }

  try {
    assert.strictEqual(input.userName, expected.userName);
    assert.strictEqual(input.password, expected.password);

    return ctx.body = users[0];
  } catch (e) {
    console.error(e);
    return ctx.status = 404;
  }
});

router.get('/staff/email/:address', async (ctx, next) => {
  const expected = 'foo@example.org'
  const address = ctx.params.address;

  try {
    assert.strictEqual(address, expected);

    return ctx.status = 204;
  } catch (e) {
    return ctx.status = 404;
  }
});

router.post('/staff/password-reset/token', async (ctx, next) => {
  const input = ctx.request.body;

  resetLinks.push(input);
  ctx.status = 204;
});

router.get('/staff/password-reset/verify/:token', async (ctx, next) => {
  const token = ctx.params.token;
  console.log('Token: %s', token);

  const resetLink = _.find(resetLinks, function (o) {
    return o.token === token;
  });

  if (resetLink) {
    return ctx.body = {
      email: resetLink.email,
      isExpired: Math.random() > 0.5
    }
  }

  ctx.status = 404;
});

router.post('/staff/password-reset/news-pass', async (ctx, next) => {
  /**
   * @type {{token: String, password: String}}
   */
  const body = ctx.request.body;
  console.log(body);

  ctx.status = 204;
});

router.get('/staff/:id/profile', async (ctx, next) => {

});

router.post('/staff/:id/profile', async (ctx, next) => {

});

router.post('/staff/:id/password', async (ctx, next) => {

});

router.post('/staff/:id/myft', async(ctx, next) => {

});

router.put('/staff/:id/vip', async (ctx, next) => {

});

app.use(router.routes());

bootApp(app, 'mock-api', 8100)
  .catch(err => {
    console.error('Bootup error: %o', err);
  });