const test = require('ava');
const random = require('../util/random');

test('token', async t => {
  const token = await random.hex();
  console.log(token);

  t.pass();
});