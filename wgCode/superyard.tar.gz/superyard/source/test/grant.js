const oauthGrant = require('../lib/oauth-grant');
const test = require('ava');

test('find', async t => {
  const item = oauthGrant.find(oauthGrant.types.client_credentials);

  console.log(item);

  t.truthy(item);
});