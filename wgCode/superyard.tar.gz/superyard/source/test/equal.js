const password = {
  old: '12345678',
  new: '12345678'
};

console.log(password.old !== password.new);