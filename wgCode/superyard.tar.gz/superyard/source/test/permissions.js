const test = require('ava');
const unixPerms = require('../lib/unix-perms');

test('list', async t => {
  const list = unixPerms.list();
  console.log(list);
  t.truthy(list);
});

test('add', async t => {
  const total = unixPerms.sum({
    owner: ['256', '128', '64'],
    group: ['32', '16'],
    other: ['4']
  });

  console.log(total);

  t.truthy(total);
});