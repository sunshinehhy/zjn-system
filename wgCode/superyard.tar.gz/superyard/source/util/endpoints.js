const baseUrl = 'http://localhost:3100';
const emailServie = 'http://localhost:8001/backyard';

const endpoints = Object.freeze({
  search: `${baseUrl}/search`,
  staff: `${baseUrl}/staff`,
  staffAuth: `${baseUrl}/staff/auth`,
  staffPasswordReset: `${baseUrl}/staff/password-reset`,
  staffAll: `${baseUrl}/staff/all`,
  staffActive: `${baseUrl}/staff/active`,
  staffProfile: `${baseUrl}/staff/profile`,
  adminStaff: `${baseUrl}/admin/staff`,
  adminVip: `${baseUrl}/admin/vip`,
  ftcApp: `${baseUrl}/apps/ftc`,
  cmsApp: `${baseUrl}/apps/cms`,
  personalToken: `${baseUrl}/tokens/personal`,
  emailPasswordReset: `${emailServie}/password`,
  emailWelcome: `${emailServie}/welcome`
});

module.exports = endpoints