const debug = require('./debug')('api:errors');

exports.notFound = function(msg='Not Found') {
  const err = new Error(msg);
  err.status = 404;
  return err;
}

/**
 * 
 * @param {Error} joiErr 
 * @param {boolean} joiErr.isJoi
 * @param {string} joiErr.name
 * @param {Object[]} joiErr.details
 * @param {string} joiErr.details[].message
 * @param {string[]} joiErr.details[].path
 * @param {string} joiErr.details[].type
 * @param {Object} joiErr.details[].context
 * @param {number} joiErr.details[].context.limit
 * @param {string} joiErr.details[].context.value
 * @param {string} joiErr.details[].context.encoding
 * @param {string} joiErr.details[].context.key
 * @param {string} joiErr.details[].context.label
 * @param {string} resource 
 * @param {string} message 
 */
exports.handleJoiErr = function (joiErr) {
  if (!joiErr.isJoi) {
    throw joiErr;
  }

  const ret = [];

  const err = joiErr.details[0];

  const field = err.context.key

  ret[field] = err.message;

  return ret;
};