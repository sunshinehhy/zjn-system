const validator = require('validator');
const _ = require('lodash');

exports.defined = function(val, msg) {
  if (_.isNil(val)) {
    throw new Error(msg);
  }
}

exports.equals = function(str, comparison, msg) {
  const a = validator.trim(str);
  const b = validator.trim(comparison);
  if (validator.isEmpty(a) || validator.isEmpty(b)) {
    throw new Error('Empty input is not allowed');
  }
  if (!validator.equals(a, b)) {
    throw new Error(msg);
  }
  return [a, b];
};

exports.notEquals = function(str, comparion, msg) {

  const a = validator.trim(str);
  const b = validator.trim(comparison);
  if (validator.isEmpty(a) || validator.isEmpty(b)) {
    throw new Error('Empty input is not allowed');
  }

  if (validator.equals(validator.trim(str), validator.trim(comparion))) {
    throw new Error(msg);
  }

  return [a, b];
}

exports.ftcEmail = function(str) {
  if (_.isNil(str) || !_.isString(str)) {
    throw new Error('Email is empty');
  }
  
  const email = validator.trim(str);
  if (!validator.isEmail(email) || !email.endsWith('@ftchinese.com')) {
    throw new Error('Not an ftchinese email');
  }
  return email;
}