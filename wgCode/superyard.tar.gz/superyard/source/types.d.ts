// A cms user's profile
declare interface ICMSUser {
    id: number;
    login: string;
    email?: string;
    isActive: boolean;
    displayName?: string;
    department?: string;
    groupMembers: number;
    vipId: string;
    vipEmail?: string;
    createdAt: string;
    deactivatedAt?: string;
    updatedAt?: string;
    lastLoginAt: string;
    lastLoginIp?: string;
}

declare interface IMyft {
    myftId: string;
    myftEmail: string;
    isVip: boolean;
}

declare interface ICMSLogin {
    login: string;
    password: string;
    ip: string;
}

// CMS user authentication result
declare interface ICMSAuth {
    id: number;
    login: string;
    displayName: string;
    department: string;
    groups: number;
    myftEmail: string;
}

declare interface ISession {
    id: number;
    name: string;
    display: string;
    groups: number;
    dpmt: string;
}

// A new cms user
declare interface ICMSUserInput {
    login: string;
    email: string;
    displayName?: string;
    department?: string;
    groupMembers?: number;
}

// App's oauth credentials
declare interface IOAuth {
    clientId: string;
    clientSecret: string;
}

// All data of a ftc app
declare interface IFTCApp {
    id: string;
    name: string;
    clientId: string; // 10 bytes
    clientSecret: string; // 32 bytes
    grantType: number;
    repoUrl: string;
    description?: string;
    homeUrl?: string;
    callbackUrl?: string;
    isActive: boolean;
    ownerId: number;
    ownerName: string;
    createdAt: string;
    updatedAt: string;
}

// Data to create a new ftc app.
declare interface IFTCAppInput {
    name: string;
    grantType?: number;
    repoUrl: string;
    description?: string;
    homeUrl?: string;
    callbackUrl?: string;
    ownerId: number;
}

// All data of a cms app
declare interface ICMSApp {
    id: number;
    name: string;
    clientId: string;
    clientSecret?: string;
    repoUrl: string;
    description?: string;
    homeUrl?: string;
    callbackUrl?: string;
    isActive: boolean;
    ownerId: number;
    ownerName: string;
    groupId: number;
    unixPerms: number;
    createdAt: string;
    updatedAt: string;
}

declare interface IPermissions {
    owner: string[];
    group: string[];
    other: string[]
}

// Data to update a cms app
declare interface ICMSAppInput {
    name: string;
    reporUrl: string;
    description?: string;
    homeUrl?: string;
    callbackUrl?: string;
    ownerId: number;
    groupId: number;
    unixPerms: number
}

declare interface IAppMode {
    appId: number;
    clientName: string;
    callbackUrl: string;
    unixPerms: number;
    ownerId: number;
    groupId: number;
}

declare interface IPersonalAccess {
    id: number;
    scopes: string;
    description: string;
    isActive: boolean;
    ownerId: number;
    myftId: string;
    myftEmail: string;
    createdAt: string;
    updatedAt: string;
    lastUsedAt: string;
}

declare interface IClientAccess {
    id: number;
    token: string;
    scopes: string;
    redirectUri: string;
    expiresIn: number;
    createdAt: string;
    expiresAt: string;
    lastUsedAt: string;
    clientId: number;
}