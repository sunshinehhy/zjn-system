const render = require('../util/render');
const debug = require('../util/debug')('patio:handle-error');

module.exports = function () {
  return async function (ctx, next) {
    try {
      await next()
    } catch (e) {
      debug.error(e);

      ctx.status = ctx.state.status = e.status || 500;
  
      if (e.response) {
        ctx.state.apiError = JSON.stringify(e.response.body, null, 4);
      } else {
        ctx.state.error = {
          message: e.message,
          stack: e.stack
        }
      }

      ctx.body = await render('error.html', ctx.state);
    }
  }
}

