## Sitemap

### Login / Logout
* GET `/login`
* POST `/login`
* GET `/password-reset` Use clicked `Forgot Password` link
* POST `/password-reset` Use submitted email address.
* GET `/password-reset/:token` User clicked link in a reset email
* POST `/password-reset/:token` User entered new password
* GET `/logout`

### User Settings
* GET `/settings/profile` Show profile
* POST `/settings/profile` Update profile
* GET `/settings/security` Show security page (currently only change password)
* POST `/settings/security/password` Update password
* GET `/settings/myft` Show page to authenticate myft account
* POST `/settings/myft` Authenticate myft account and bind it to current signed in user, or change bound myft account to another one.
* POST `/settings/vip` Let user to apply for VIP if myft account is set.

### Admin
* GET `/admin` Admin home page.

Create a new staff
* GET `/admin/new-staff` Show create new staff page
* POST `/admin/new-staff/next`
* POST `/admin/new-staff` Create a new staff

Manage staff profile
* GET `/admin/staff` Show staff roster. If pending, show `grant` or `reject`; if granted, show `revoke`; if not-appied, no button.
* GET `/admin/staff/:id` Show a staff profile
* POST `/admin/staff/:id` Update a staff profile
* POST `/admin/staff/:id/delete` Delete a staff

Mange VIP applications
* GET `/admin/vip/applications` List all pending applications
* POST `/admin/vip/:id/grant`
* POST `/admin/vip/:id/reject`
* POST `/admin/vip/:id/revoke`

### Registry

Registration of apps; manage client access tokens; generate personal access token.

#### FTC Clients
* GET `/registry` Guide on registry usage
* GET `/registry/ftc` Show the list of ftc client apps, including those not owned by current user. Current user could only edit those he owns.
* GET `/registry/ftc/new` Create a new record of ftc app.
* POST `/registry/ftc/new`
* GET `/registry/ftc/:appId` Show details of `appId`
* POST `/registry/ftc/:appId` Update `appId`
* POST `/registry/ftc/:appId/reset-secret`
* GET `/registry/ftc/:appId/transfer` Show transfer page with candidates
* POST `/registry/ftc/:appId/transfer`
* POST `/registry/ftc/:appId/delete` When deleting an app, all access tokens applied by it should also be revoked. This is done by API.
* GET `/registry/ftc/:appId/tokens` Show access tokens applied by `appId`
* POST `/registry/ftc/:appId/tokens/revoke`

#### Bakyard Clients

* GET `/registry/backyard` Show all backyard app.
* GET `/registry/backyard/new` Create a backyard app
* POST `/registry/backyard/new`
* GET `/registry/backyard/:appId` Show details of an app
* POST `/registry/backyard/:appId` Update `appId`
* POST `/registry/backyard/:appId/reset-secret`
* GET `/registry/backyard/:appId/transfer`
* POST `/registry/backyard/:appId/transfer`
* POST `/registry/backyard/:appId/delete`

#### Person Access Tokens

* GET `/registry/tokens` Show all tokens owned by current user
* GET `/registry/tokens/new` Create a new personal access token
* POST `/registry/tokens/new`
* POST `/registry/tokens/revoke-all` This should also be perfomred automatically when a user is deleted by admin (which usually means this staff resigned his job).
* GET `/registry/tokens/:tokenId` Show details of a token
* POST `/registry/tokens/:tokenId` Update a token information
* POST `/registry/tokens/:tokenId/regenerate` Regnerate this token (for example, this token might be leaked to external world).
* POST `/registry/tokens/:tokenId/revoke` Delete a token

## How to run

Run the mock restful api:

```
nodemon --config mock-api/nodemon.json mock-api/index.js
```

Then in a new terminal:
```
nodemon index.js
```